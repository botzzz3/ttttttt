const donasi = () => {
	return `	

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 0857-2255-3839
┣➥ *PULSA:* 0821-9857-1732
┣➥ *Saweria*:
┃   https://bit.ly/37tClAQ
┣━━━━━━━━━━━━━━━━━━━━
┃Thanks To : Aris187 ID
┃Follow Ig : @sadboy_ig
┃Owner Bot : Muhammad Akbar
┃Follow Ig : @barxnl
┃ 
┃Sc ini dari Aris187 ID.
┃Jika ingin donasi Silahkan!
┣━━━━━━━━━━━━━━━━━━━━
┃ 🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
