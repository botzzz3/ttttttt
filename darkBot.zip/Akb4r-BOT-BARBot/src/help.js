const help = (prefix) => {
	return `🤖⚠️🤖⚠️⚠️⚠️🤖⚠️🤖
	
	                

┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *Adesivo $ {prefix} * [foto]
┣➥ *${prefix} stickergif * [foto]
┣➥ *${prefix} adesivo nobg
┣➥ *${prefix} trovão * [texto]
┣➥ *${prefix} tsticker * [text / url]
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix} tts * [texto]
┣➥ *${prefix} ocr *
┣➥ *${prefix} loli *
┣➥ *${prefix} toimg *
┣➥ *${prefix} meme *
┣➥ *${prefix} memeindo *
┣➥ *${prefix} nsfwloli *
┣➥ *${prefix} espere * [foto]
┣➥ *${prefix} simi
┣➥ *${prefix} simih *
┣➥ *${prefix} espere *

┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃
┣{prefix} setname *
┣➥ * $ {prefix}setdesc *
┣➥ * $ {prefix}getpp *
┣➥ * $ {prefix}tagall *
┣➥ * $ {prefix}grupo de links
┣➥ * $ {prefix}gprofile *
┣➥ * $ {prefix}setprefix
┣➥ * $ {prefix}bem-vindo *
┣➥ * $ {prefix}restante *
┃
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━━⊱
┃
┣➥ *saudações*
┣➥ *puxar*
┣➥ *baka*
┣➥ *suspiro*
┣➥ *estupido*
┣➥ *pao*
┣➥ *welot*
┣➥ *irmao *
┃
┣━━━━━━━━━━━━━━━━━━━━
┃criado por: charope,malokeiro 
┣━━━━━━━━━━━━━━━━━━━━
┃ 🤖⚠️🤖⚠️🤖⚠️🤖⚠️🤖⚠️🤖⚠️🤖⚠️
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help


